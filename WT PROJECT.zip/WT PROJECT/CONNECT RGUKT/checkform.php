<!DOCTYPE html>
<html>
<head>
    <title>FORM VALIDATION IN JAVASCRIPT</title>
    
</head>
    <body>
<form action="index.html" id="form"><br>
<label>USERNAME:</label><br><br>
<input type="text" name="uname" id="uname"><br>
<span id="error"></span><br>
<label>PASSWORD:</label><br><br>
<input type="password" name="pswd" id="pd"><br>
<span id="perror"></span><br>
<input type="checkbox" name="show" id="box" onclick="naren()">
<label>Show password</label><br><br>
<label>CONFIRM PASSWORD:</label><br><br>
<input type="password" name="conform" id="cpd"><br>
<span id="cerror"></span><br>
<label>PHONE NUMBER:</label><br><br>
<input type="tel" name="number" id="no" size="10" minlength="1" maxlength="10"><br>
<span id="terror"></span><br>
<label>EMAIL:</label><br><br>
<input type="text" name="mail" id="email"><br>
<span id="merror"></span><br>
<input type="checkbox" name="checked" id="check">
<label> I accept the <u>Terms and Conditions</u></label><br>
<span id="checkerror"></span><br>
<button type="submit">SUBMIT</button>
<br><br>
</form>
    <script>
        let form=document.getElementById('form');

        let uname=document.getElementById('uname');
        let upass=document.getElementById('pd');
        let ucpass=document.getElementById('cpd');
        let utel=document.getElementById('no');
        let umail=document.getElementById('email');
        let ucheck=document.getElementById('check');

        let uerror=document.getElementById('error');
        let perror2=document.getElementById('perror');
        let cerror2=document.getElementById('cerror');
        let terror2=document.getElementById('terror');
        let merror2=document.getElementById('merror');
        let checkerror2=document.getElementById('checkerror');

        form.addEventListener("submit",event=>{event.preventDefault();validate();})
        function validate(){

            let name=uname.value.trim();
            let psd=upass.value.trim();
            let cpsd=ucpass.value.trim();
            let telph=utel.value.trim();
            let em=umail.value.trim();

            if(name===""||name==null){
                uerror.innerText="cant be empty";
            }
             else if(name.length<3){
                uerror.innerText="must be conatin 3 letters";
                }
           else if(!isNaN(name)){
                uerror.innerText="only alphabets";
            }
            else if(psd===""||psd==null){
                perror2.innerText="password cant be empty";
            }
            else if(!(psd.match(/[a-z]+[A-Z]+[0-9]+/) || (/[A-Z]+[a-z]+[0-9]/))){
                perror2.innerText="must used aleast one capital,small,digit";
            }
            else if(!psd.match(/[#_@$^%]/)){
                perror2.innerText="contain atleast one special character";
            }
            else if(psd!=cpsd){
                cerror2.innerText="Not match";
            }
            else if(telph===""||telph==null){
                terror2.innerText="telphone cant be empty";
            }
            else if(!telph.match(/[6-9][0-9]{9}/)){
                terror2.innerText="invalid number";
            }
            else if(em===""||em==null){
                merror2.innerText="email cant be empty";
            }
            else if(!(em.match(/^[a-zA-Z0-9_/.-]+@[a-zA-Z0-9_-]+(?:\.[a-z]{2,6})$/))){
                merror2.innerText="invalid mail";
            }
            else if(ucheck.checked === false){
                checkerror2.innerText="Please accept the terms and conditions";
            }
            else{
       	        form.submit();
       	    }
        } 
        function naren(){
            if(upass.type=="password"){
                upass.type="text";
            }
            else{
                upass.type="password";
            }
        }     
    </script>
    
</body>
</html>