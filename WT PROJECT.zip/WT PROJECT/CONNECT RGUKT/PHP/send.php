<?php
include 'conn.php';


$NAME = $_POST['user'];
$feeddback= $_POST['feed'];
echo $NAME;
echo $feeddback;
 
$query ="INSERT INTO `FEEDBACK`(`NAME`, `feed`) values('$NAME','$feeddback' ); ";
if(mysqli_query($connetion,$query)){
    echo "record inserted".'<br>';
}


$query = "SELECT * FROM FEEDBACK;";
$check = mysqli_query($connetion,$query);
if(mysqli_num_rows($check)){
	?>
	<table border='1' style="border-collapse:collapse; text-align: center;">
			<tr>
				
				<th>NAME </th>
				<th>feedback on my project </th>
				
			</tr>
			<?php
			while($row  = mysqli_fetch_assoc($check)){
			?>
							
				<tr>
					
				<td><?php  echo $row["NAME"];?></td>
				<td><?php  echo $row["feed"];?></td>
					
				</tr>				
				<?php 
			}
				?>
	</table>
	
	<?php	
	     
		    
		    
	
}
mysqli_close($connetion);
 
?>
