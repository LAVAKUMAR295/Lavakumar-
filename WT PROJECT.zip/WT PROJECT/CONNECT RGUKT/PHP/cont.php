<?php
if (isset($_POST['sub'])) {
  $to = "lavakumarlavakumar295@gamil.com"; // this is your Email address
  $from = $_POST['email']; // this is the sender's Email address
  $name = $_POST['name'];
  $subject = "Form submission";
  $message = $name . " " . $from . " wrote the following:" . "\n\n" . $_POST['message'];

  $headers = "From:" . "kesarapukartik989@gmail.com";
  mail($to, $subject, $message, $headers);
  echo "Mail Sent. Thank you " . $name . ", we will contact you shortly.";
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact Us</title>
  <link rel="icon" type="image/png" href="../Images/alps_favicon.png">
  <meta name="description" content="Connect with people over travelling">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../CSS/contact-us.css">
  
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans:wght@300&family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
</head>

<body background="download.png" style="background-repeat:no-repeat;background-size:100%130%">>
  <section class="contact" IMG_20220615_075519.jpg>
    <div class="container">
      <!-- contact information of the Developers -->
      <div class="contact-info">
        <a href="../index.html">
          <h2>Connect RGUKT</h2>
        </a>
        <div class="box">
          <div class="icon">
            <i class="fas fa-map-marker-alt"></i>
          </div>
          <div class="text">
            <h3>Address:</h3>
            <p>BH2, RKVALLY, RGUKT</p>
          </div>
        </div>

        <div class="box">
          <div class="icon">
            <i class="fas fa-envelope"></i>
          </div>
          <div class="text">
            <h3>Email:</h3>
            <p>lavakumarlavakumar295@gmail.com & karthikkesarapu@gmail.com</p>
          </div>
        </div>

        <div class="box">
          <div class="icon">
            <i class="fas fa-phone"></i>
          </div>
          <div class="text">
            <h3>Phone:</h3>
            <p>7989242509 & 9441133916</p>
          </div>
        </div>
      </div>

     
      <div class="contact-form">
        <form action="cont.php" method="POST">
          <h2>Send Message</h2>
          <div class="input-box">
            <input type="text" name="name" value="" required placeholder="Name">
          
            <br><BR>
          </div>
          <div class="input-box">
            <input type="text" name="email" value="" required placeholder="email">
          
            <br><BR>
          </div>
          <div class="input-box">
            <textarea name="message" rows="5" cols="30" required>Enter Messages</textarea>
            
            <br><br>
          </div>
          <div class="input-box">
            <input type="submit" name="sub" value="send">
          </div>
        </form>
      </div>
    </div>
  </section>

</body>

</html>