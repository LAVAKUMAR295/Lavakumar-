<?php
 
session_start();
 
if(isset($_GET['logout'])){    
     
    //Simple exit message
    $logout_message = "<div class='msgln'><span class='left-info'>User <b class='user-name-left'>". $_SESSION['name'] ."</b> has left the chat session.</span><br></div>";
    file_put_contents("log.html", $logout_message, FILE_APPEND | LOCK_EX);
     
    session_destroy();
    header("Location: index.php"); //Redirect the user
}
 
if(isset($_POST['enter'])){
    if($_POST['name'] != ""){
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    }
    else{
        echo '<span class="error">Please type in a name</span>';
    }
}
 
function loginForm(){
    echo
    '<div id="loginform">
    <p>wecome to rgukt!</p>
    <p><em>Enter your name !</em></p>
    <form action="index.php" method="post">
      <label for="name">Name &mdash;</label>
      <input type="text" name="name" id="name" />
      <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
  </div>';
}
 
?>
 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
 
        <title>connect rgukt</title>
        <meta name="description" content="connect rgukt Chat Application" />
        <link rel="stylesheet" href="style.css" />
        
    </head>
    <body>
    <?php
    if(!isset($_SESSION['name'])){
        loginForm();
    }
    else {
    ?>
        <div id="wrapper">
            <div id="menu">
                <p class="welcome">heloo, <b><?php echo $_SESSION['name']; ?></b></p>
                <p class="logout"><a id="exit" href="#">leave from site</a></p>
            </div>
            <img src="you.jpeg" width="100" align="left">
            <img src="2022-09-07-112441.jpg" width="100" align="left">
            <img src="str.jpeg" width="150" align="right">
            <img src="nodp.png" width="50" align="right">
            <div id="chatbox">
            <?php
            if(file_exists("log.html") && filesize("log.html") > 0){
                $contents = file_get_contents("log.html");          
                echo $contents;
            }
            ?>
            </div>
            
 
            <form name="message" action="">
                <input name="usermsg" type="text" id="usermsg" />
                <input name="submitmsg" type="submit" id="submitmsg" value="Send" />
            </form>
        </div>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script type="text/javascript">
            // jQuery Document
            $(document).ready(function () {
                $("#submitmsg").click(function () {
                    var clientmsg = $("#usermsg").val();
                    $.post("post.php", { text: clientmsg });
                    $("#usermsg").val("");
                    return false;
                });
 
                function loadLog() {
                    var oldscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Scroll height before the request
 
                    $.ajax({
                        url: "log.html",
                        cache: false,
                        success: function (html) {
                            $("#chatbox").html(html); //Insert chat log into the #chatbox div
 
                            //Auto-scroll           
                            var newscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Scroll height after the request
                            if(newscrollHeight > oldscrollHeight){
                                $("#chatbox").animate({ scrollTop: newscrollHeight }, 'normal'); //Autoscroll to bottom of div
                            }   
                        }
                    });
                }
 
                setInterval (loadLog, 2500);
 
                $("#exit").click(function () {
                    var exit = confirm("Are you sure you want Disconnect with rgukt?");
                    if (exit == true) {
                    window.location = "index.php?logout=true";
                    }
                });
            });
        </script>
        <h3  style="color:purple"> In Future:</h3>
        <i>we can modify the above chat page into enabling<b> audio and video</b> for users for face to face contact,and also for group discussions we can add <b>multiple connect</b>with video and audion like google meet.
        and also enables the <b>pen</b> for writing and explainations.Add<b> all social media to use together at a time</b>.</i> 
        <h2>when ever you got strees or any nurves you can use my games to relax:</h2>
        <h2 style="color:aqua">In future: </h2>
        <i> we can develop this game to virtual reality game all rgukatians can play game with their<b> own faces</b>,and also add <b>loby is my village</b> then flight can take players to Rkvalley when we locate any place here shown in map like <b>hostels,hospital,ground,Ablocks,Guest house,courtuse, etc..</b>Then we land there and randomly we got<b> guns,grandes,pistols,snipers,sticks,meele,knifes, etc...</b> Then fight each other to survive upto end who is <b>remains upto last</b> of this battel he or she<b> win</b> the match.On every winning we contribute to <b>H.H.O</b>money by their names .The maximum limit of players per match is<b>100</b>.     </i>
        <h3> click the next button you can see intro of the Game....!</h3>
        <h3  style="color:rgb(24, 37, 221)"> This is just a trail u see never seen!..-BY #karthik and #lavakumar</h3>
        <form action="game.html">
           <input type="submit" value="next"> 
        </from>
        
        
    </body>
</html>
<?php
}
?>