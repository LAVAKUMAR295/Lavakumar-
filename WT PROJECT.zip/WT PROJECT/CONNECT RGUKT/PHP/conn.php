<?php
$connetion =mysqli_connect("localhost","root","" ,"REGISTRATION");
if($connetion){
    echo "connection established      ";
}
else{
    echo "error/: ".mysqli_error($connetion);
}

?>